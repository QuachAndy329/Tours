<?php
include_once 'config.php';
include_once 'dbConnect.php';
?>

<div class = "container">
<h1>paypal intergration</h1>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Bootstrap E-Commerce Template</title>
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!-- Fontawesome core CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <!--GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <!--Slide Show Css -->
    <link href="assets/ItemSlider/css/main-style.css" rel="stylesheet" />
    <!-- custom CSS here -->
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
    
</body>
</html>

<?php
//fetch products from database
$results = $db->query("SELECT * FROM products WHERE status = 1"); 
while($row = $results->fetch_assoc()){
?>

<div class="row">
    <img width="150" height="150" src="images/<?php echo $row['image']; ?>"/>
    <div class="col-sm-6"> 
        <h5><?php echo $row['name']; ?></h5>
        <h6>price: <?php echo '$' .$row['price'].' ' .PAYPAL_CURRENCY; ?></h6>

<!-- Paypal payment form for displaying the buy button -->
<form action="<?php echo PAYPAL_URL; ?>" method="post"> 

<!-- Identify your Business form  for displaying the buy button --> 
<input type="hidden" name="business" value="<?php echo PAYPAL_ID; ?>">

<!-- specify a buy button --> 
<input type="hidden" name="cmd" value="_xclick">

<!-- specify detail --> 
<input type="hidden" name="item_name" value="<?php echo $row['name']; ?>">
<input type="hidden" name="item_number" value="<?php echo $row['id']; ?>">
<input type="hidden" name="amount" value="<?php echo $row['price']; ?>">
<input type="hidden" name="currency_code" value="<?php echo PAYPAL_CURRENCY;?>">

<!-- specify URLs --> 
<input type="hidden" name="return" value="<?php echo PAYPAL_RETURN_URL; ?>">
<input type="hidden" name="cancel_return" value="<?php echo PAYPAL_CANCEL_URL; ?>">
<input type="hidden" name="notify_url" value="<?php echo PAYPAL_NOTIFY_URL; ?>">

<!-- display --> 
<input type="image" name="submit" border="0"
src="https://www.paypalobjectives.com/en_US/i/btn/btn_buynow_LG.gif">
</form>
    </div>
</div>
<?php } ?>
</div>


