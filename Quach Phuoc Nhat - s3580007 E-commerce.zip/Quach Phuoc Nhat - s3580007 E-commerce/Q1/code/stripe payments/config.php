<?php 
// Product Details 
// Minimum amount is $0.50 US 
$itemName = "Demo Product"; 
$itemNumber = "PN12345"; 
$itemPrice = 100; 
$currency = "AUD"; 
 
// Stripe API configuration  
define('STRIPE_API_KEY', 'sk_test_51HY3rQCehPkWa5uqifvSwfHURjsauBlLGta6oGEfxyOAVTU1PjHoh0Ib
xYlfrrIHIbFQLzUkH9luDFxHAzFlOJuX004KDicES7'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51HY3rQCehPkWa5uq3qzQGxYUVU
miexxwPgMTb8LFny2aoCTMD9JXV0wQKdW7cfOf3I2kNZ04byWsP2eeaWLa0mAj00wIW6kLQV'); 
  
//database Configuration 
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root');
define('DB_PASSWORD', ''); 
define('DB_NAME', 'stripe'); 