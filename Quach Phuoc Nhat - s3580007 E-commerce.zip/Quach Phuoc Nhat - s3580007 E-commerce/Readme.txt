﻿Thanks you
Thank you for reading this readme doc Tut/Lecturer. 
Big special thanks for Mr. Vu Mai and Mr. Ibrahim to company me this semester. 


This semester has been a nightmare for me trying to keep in touch with the course and other 2 courses in this semester due to the Pandemic we currently experience now. 


Thanks you Mr. Ibrahim has been forgiving in both the assignments the class can experience and help us extend the time we need to get the maximum grade for our Assignments.  


The Question 1 read me 


Most of the code that I got is based on the slide lecture and developed from it, it is a raw website and only has the function integration work due to the difficulty of the coding that I found it difficult. 


I tried my best to overcome my difficulty in coding despite the time were given to me I have hard time coding a easy to look website and can only offer this Question 1 with Raw website